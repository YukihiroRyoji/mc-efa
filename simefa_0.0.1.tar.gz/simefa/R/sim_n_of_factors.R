#' 平行分析による因子数決定のシミュレーション
#'
#' 平行分析による因子数決定のシミュレーション
#'
#' @param filenames シミュレーションデータのファイル名を納めたベクトル
#' @param multicore TRUEの場合，CPUのマルチコアを使って並列計算を行う。Windows環境では使用不可でありFALSEとする。ただし，Windowsのwslでlinux環境を使えばしよう可能。
#' @param ... psych:fa.parallelに渡す追加引数。因子抽出法(fm)やcor="poly"等が使える。
#' @export
sim_n_of_factors.parallel <- function(filenames, multicore=FALSE, ...) {
  if (multicore) {
    mcores <- parallel::detectCores()
  } else {
    mcores <- 1
  }
  nfactor <- parallel::mclapply(filenames, function(fn) {
    data1 <- utils::read.table(fn)
    utils::capture.output(npal <- psych::fa.parallel(data1, plot=FALSE, ...))
    return(list(nfact=npal$nfact, ncomp=npal$ncomp))
  }, mc.cores=mcores, mc.set.seed=TRUE)
  nfactor <- list(
    nfact=table(sapply(nfactor, function(x) {x$nfact[1]})),
    ncomp=table(sapply(nfactor, function(x){x$ncomp[1]})))
  class(nfactor) <- "nfactors"
  nfactor
}

#' @export
print.nfactors <- function(x, ...) {
  cat("Suggested number of factors:")
  print(x$nfact)

  cat("\nSuggested number of components:")
  print(x$ncomp)
}
