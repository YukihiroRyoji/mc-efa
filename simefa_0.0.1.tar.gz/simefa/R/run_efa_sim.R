#' EFAシミュレーションの実行
#'
#' EFAシミュレーションの実行
#'
#' @param fload 因子負荷行列
#' @param fcor 因子間相関行列
#' @param datafiles シミュレーション用に生成したデータファイル名を納めたベクトル
#' @param vars データファイルの一部の列のみを使う場合に列インデックスを指定する。NULL(default)の場合はすべての列を使う。
#' @param multicore TRUEの場合，CPUのマルチコアを使って並列計算を行う。Windows環境では使用不可でありFALSEとする。ただし，Windowsのwslでlinux環境を使えばしよう可能。
#' @param rotation 因子回転方法の指定。targetの場合はfcorをターゲットにターゲット回転を行う。psych::target.rot参照。
#' @param cor 使用する相関行列。"cor"はpearsonの相関係数。"poly"で多分相関係数。psych::fa参照。
#' @param fm 因子抽出方法の指定。psych::fa参照
#'
#' @export
run_efa_sim <- function(fload, fcor, datafiles, vars=NULL, multicore=FALSE, rotation="geominQ", cor="cor", fm="ml") {
  # windowsでは実行不可，または1
  if (multicore) {
    mcores <- parallel::detectCores()
  } else {
    mcores <- 1
  }
  sim_result <- parallel::mclapply(datafiles,
                                   function(filename) {
                                     data1 <- get_efa_data(filename, vars=vars)
                                     fit_efa_sim(data1, fload, fcor, rotation=rotation, cor=cor, fm=fm)
                                   },
                                   mc.cores=mcores, mc.set.seed=TRUE)
  class(sim_result) <- "efaSimListArray"
  return(sim_result)
}


#' EFAシミュレーションの要約出力
#'
#' EFAシミュレーションの要約出力
#'
#' @param object efaSimListArrayクラスのオブジェクト。run_efa_sim()関数の出力。
#' @param lower シミュレーション結果の分布出力の下限
#' @param upper シミュレーション結果の分布出力の上限
#' @param plot TRUEの場合，Kのヒストグラムを描画
#' @param ... 追加引数
#'
#' @export
summary.efaSimListArray <- function(object, lower=.05, upper=.95, plot=FALSE, ...) {
  n <- length(object)
  ss <- object[[1]]$samplesize
  nfac <- ncol(object[[1]]$loadings)
  nvar <- nrow(object[[1]]$loadings)
  ks <- rep(NA, n)
  ds <- rep(NA, n)
  fload <- matrix(NA, n, nfac*nvar)
  fcor <- matrix(NA, n, nfac*nfac)
  for (i in 1:n) {
    ks[i] <- object[[i]]$K
    ds[i] <- object[[i]]$D
    fload[i,] <- c(object[[i]]$loadings)
    fcor[i,] <- c(object[[i]]$factor_correlations)
  }
  fload.mean <- matrix(apply(fload, 2, mean), nvar, nfac)
  fload.sd <- matrix(apply(fload, 2, stats::sd), nvar, nfac)
  flq <- apply(fload,2,stats::quantile, c(lower, .5, upper))
  fload.lower <- matrix(flq[1,], nvar, nfac)
  fload.median <- matrix(flq[2,], nvar, nfac)
  fload.upper <- matrix(flq[3,], nvar, nfac)

  fcor.mean <- matrix(apply(fcor, 2, mean), nfac, nfac)
  fcor.sd <- matrix(apply(fcor, 2, stats::sd), nfac, nfac)
  frq <- apply(fcor, 2, stats::quantile, c(lower, .5, upper))
  fcor.lower <- matrix(frq[1,], nfac, nfac)
  fcor.median <- matrix(frq[2,], nfac, nfac)
  fcor.upper <- matrix(frq[3,], nfac, nfac)

  # V (variability of factor solutions)
  V <- apply(fload, 1,
             function(fl){
               fl_diff <- matrix(fl, nvar, nfac) - fload.mean
               sqrt(psych::tr(t(fl_diff) %*% fl_diff)/(nvar*nfac))
             })

  colnames(fload.mean) <- paste0("f",1:nfac)
  rownames(fload.mean) <- paste0("y", 1:nvar)
  colnames(fload.sd) <- paste0("f",1:nfac)
  rownames(fload.sd) <- paste0("y", 1:nvar)
  colnames(fcor.mean) <- paste0("f",1:nfac)
  rownames(fcor.mean) <- paste0("f", 1:nfac)
  colnames(fcor.sd) <- paste0("f",1:nfac)
  rownames(fcor.sd) <- paste0("f", 1:nfac)

  if (plot) graphics::hist(ks, xlab="K", main="")

  res <- list(n_of_replications=n, sample_size=ss,
              factor_loadings_mean=fload.mean,
              factor_loadings_sd=fload.sd,
              factor_correlations_mean=fcor.mean,
              factor_correlations_sd=fcor.sd,
              K=ks,
              K_mean=mean(ks),
              K_sd=stats::sd(ks),
              quantile_of_K=stats::quantile(ks,c(lower, .50, upper)),
              D=ds,
              D_mean=mean(ds),
              D_sd=stats::sd(ds),
              quantile_of_D=stats::quantile(ds,c(lower, .50, upper)),
              V=V,
              V_mean=mean(V),
              V_sd=stats::sd(V),
              quantile_of_V=stats::quantile(V, c(lower, .50, upper)),
              factor_loadings_lower=fload.lower,
              factor_loadings_median=fload.median,
              factor_loadings_upper=fload.upper,
              factor_correlations_lower=fcor.lower,
              factor_correlations_median=fcor.median,
              factor_correlations_upper=fcor.upper,
              quant_prob=c(lower, .5, upper),
              population_factor_loadings=object[[1]]$population_loadings,
              population_factor_correlations=object[[1]]$population_factor_correlations
  )
  class(res) <- "summary_efaSimListArray"
  res
}


#' @export
print.summary_efaSimListArray <- function(x, ...){
  cat("N of Replications:", x$n_of_replications, "\n")
  cat("Sample Size: ", x$sample_size, "\n")
  cat(sprintf("\nMean(SD) Congruence Coefficients(K): %.3f (%.3f)\n", x$K_mean, x$K_sd))
  cat("Quantile of K:\n")
  print(round(x$quantile_of_K,3))
  cat(sprintf("\nMean(SD) Discrepancy(D): %.3f (%.3f)\n", x$D_mean, x$D_sd))
  cat("Quantile of D:\n")
  print(round(x$quantile_of_D,3))
  cat(sprintf("\nMean(SD) Variability of Factor Solutions(V): %.3f (%.3f)\n", x$V_mean, x$V_sd))
  cat("Quantile of V:\n")
  print(round(x$quantile_of_V,3))

  cat("\n\n[Factor Loadings]\n")
  for (i in 1:ncol(x$factor_loadings_mean)) {
    cat("\nFactor ", i, ":\n", sep="")
    fl <- format(round(cbind(
      x$population_factor_loadings[,i],
      x$factor_loadings_mean[,i],
      x$factor_loadings_sd[,i],
      x$factor_loadings_lower[,i],
      x$factor_loadings_median[,i],
      x$factor_loadings_upper[,i]
    ),3), nsmall=3)
    colnames(fl) <- c("Population", "Average", "SD", paste0(x$quant_prob*100,"%"))
    print(fl, quote=FALSE)
  }

  cat("\n\n[Factor Correlations]\n")
  nfac <- ncol(x$factor_correlations_mean)
  for (i in 1:(nfac-1)) {
    cat("\nFactor ",i," with\n", sep="")
    fr <- format(round(cbind(
      x$population_factor_correlations[(i+1):nfac,i],
      x$factor_correlations_mean[(i+1):nfac,i],
      x$factor_correlations_sd[(i+1):nfac,i],
      x$factor_correlations_lower[(i+1):nfac,i],
      x$factor_correlations_median[(i+1):nfac,i],
      x$factor_correlations_upper[(i+1):nfac,i]
    ),3), nsmall=3)
    colnames(fr) <- c("Population", "Average", "SD", paste0(x$quant_prob*100,"%"))
    rownames(fr) <- paste("Factor", 1:nrow(fr))
    print(fr, quote=FALSE)
  }

  invisible(x)
}

