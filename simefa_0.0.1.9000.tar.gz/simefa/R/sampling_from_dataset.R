#' データセットからシミュレーション用データのサンプリングを行う
#'
#' データセットからシミュレーション用データのサンプリングを行う
#' @param x サンプリング元のデータ
#' @param samplesize サンプルサイズ
#' @param nrep シミュレーション回数
#' @param datadir サンプリングしたデータを保存するディレクトリー
#' @param vars 使用する変数のインデックス。default(vars=NULL)の場合は全ての変数を使う。
#'
#' @export
sampling_from_dataset <- function(x, samplesize, nrep, datadir, vars=NULL ) {
  n <- nrow(x)
  if (is.null(vars)) {
    vars <- 1:ncol(x)
  }
  nvar <- length(vars)

  dir_check(datadir)
  datafiles <- paste0(datadir,"/data_",1:nrep, ".dat")
  for (i in 1:nrep) {
    k <- sample(1:n, samplesize)
    dat1 <- x[k,vars]
    utils::write.table(dat1, datafiles[i])
  }
  return(datafiles)
}

#' 因子分析の結果を母集団モデルとして使用するために読み出す
#'
#' 因子分析の結果を母集団モデルとして使用するために読み出す
#' @param x 分析対象データ
#' @param ... psych::fa関数に渡す追加引数
#' @export
set_factor_model_from_dataset <- function(x, ...) {
  re <- psych::fa(x, ...)
  fld <- unclass(re$loadings)
  return(list(factor_loadings=unclass(re$loadings), factor_correlations=re$Phi))
}
