#' シミュレーション用のデータを生成する
#'
#' シミュレーション用のデータを生成する
#'
#' @param fload 因子負荷行列
#' @param fcor 因子間相関行列
#' @param samplesize サンプルサイズ
#' @param nrep シミュレーション回数
#' @param datadir データを出力するディレクトリー
#'
#' @return データファイル名のベクトル
#'
#' @export
gen_efa_data <- function(fload, fcor, samplesize, nrep, datadir) {
  R <- psych::sim.structure(fload, fcor)$model
  dir_check(datadir)
  datafiles <- paste0(datadir,"/data_",1:nrep, ".dat")
  for (i in 1:nrep) {
    dat1 <- psych::simCor(R, n=samplesize, data=TRUE)
    utils::write.table(dat1, datafiles[i])
  }
  return(datafiles) # データファイルの配列を返す
}

#' 順序カテゴリー変数のシミュレーション用のデータを生成する
#'
#' 順序カテゴリー変数のシミュレーション用のデータを生成する
#'
#' @param fload 因子負荷行列
#' @param fcor 因子間相関行列
#' @param samplesize サンプルサイズ
#' @param nrep シミュレーション回数
#' @param datadir データを出力するディレクトリー
#' @param breaks 連続変数を順序カテゴリに分割する閾値ベクトル
#'
#' @return データファイル名のベクトル
#'
#' @export
gen_efa_data.categorical <- function(fload, fcor, samplesize, nrep, datadir, breaks=c(-Inf, -0.67, 0.67, Inf)) {
  R <- psych::sim.structure(fload, fcor)$model
  dir_check(datadir)
  datafiles <- paste0(datadir,"/data_",1:nrep, ".dat")
  for (i in 1:nrep) {
    dat1 <- psych::simCor(R, n=samplesize, data=TRUE)
    if (is.vector(breaks)) {
      dat2 <- apply(dat1, 2, function(x) {
        cut(x, breaks=breaks, label=FALSE)
      })
    } else if (is.matrix(breaks)) {
      dat2 <- lapply(1:ncol(dat1), function(i, x) {
        cut(x[,i], breaks=breaks[i,], label=FALSE)
      }, dat1)
    } else {
      stop("breaks must be vector or matrix.")
    }
    utils::write.table(dat2, datafiles[i])
  }
  return(datafiles) # データファイルの配列を返す
}

#' シミュレーションデータを読み込む
#'
#' シミュレーションデータを読み込む
#' @param filename データファイル名
#' @param vars データの一部の列だけを使う場合に，列インデックスを指定する
#'
#' @export
get_efa_data <- function(filename, vars=NULL) {
  data1 <- utils::read.table(filename)
  if (! is.null(vars)) {
    data1 <- data1[,vars]
  }
  names(data1) <- paste0("y",1:ncol(data1))
  return(data1)
}


dir_check <- function(dirname) { # directoryの存在チェックの関数
  wdcheck <- file.info(dirname)$isdir
  if (is.na(wdcheck)) {
    message(paste("create a directory:", dirname))
    dir.create(dirname)
  } else if(!wdcheck) {
    stop(paste(dirname, "is not a directory."))
  }
}



