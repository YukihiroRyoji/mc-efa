#' 複数種類のサンプルサイズを指定したシミュレーションデータの生成
#'
#' 複数種類のサンプルサイズを指定したシミュレーションデータの生成
#'
#' @param fload 因子負荷行列
#' @param fcor 因子間相関行列
#' @param ss 比較するサンプルサイズのベクトル
#' @param nrep 各条件でのシミュレーション回数
#' @param datadir シミュレーション用データを保存するディレクトリー
#'
#' @export
gen_multiple_efa_data <- function(fload, fcor, ss, nrep, datadir) {
  dir_check(datadir) # データディレクトリが存在するかチェックし，無ければ作る
  ret <- sim_result <- lapply(ss, function(x){
    datadir1 <- paste0(datadir, "/", x)
    gen_efa_data(fload, fcor, x, nrep, datadir1)
  })
  ret
}



#' 複数種類のサンプルサイズを指定したシミュレーション
#'
#' 複数種類のサンプルサイズを指定したシミュレーション
#'
#' @param fload 因子負荷行列
#' @param fcor 因子間相関行列
#' @param datafiles シミュレーション用データが入ったファイル名ベクトルのlist
#' @param rotation 因子回転方法の指定。targetの場合はfcorをターゲットにターゲット回転を行う。psych::target.rot参照。
#' @param cor 使用する相関行列。"cor"はpearsonの相関係数。"poly"で多分相関係数。psych::fa参照。
#' @param fm 因子抽出方法の指定。psych::fa参照
#' @param multicore TRUEの場合，CPUのマルチコアを使って並列計算を行う。Windows環境では使用不可でありFALSEとする。ただし，Windowsのwslでlinux環境を使えばしよう可能。
#'
#' @export
run_multiple_efa_sim <- function(fload, fcor, datafiles, rotation="geominQ", cor="cor", fm="ml", multicore=FALSE) {
  ret <- lapply(datafiles, function(x) {
    run_efa_sim(fload, fcor, x, multicore=multicore, rotation=rotation, cor=cor, fm=fm)
    })
  class(ret) <- "efaSimListArrayArray"
  return(ret)
}


#' @export
print.efaSimListArrayArray <- function(x, ...) {
  nss1 <- length(x)
  smry <- lapply(x, summary.efaSimListArray, plot=FALSE)

  ss1 <- rep(NA, nss1)
  kmean <- rep(NA, nss1)
  ksd <- rep(NA, nss1)
  dmean <- rep(NA, nss1)
  dsd <- rep(NA, nss1)
  vmean <- rep(NA, nss1)
  vsd <- rep(NA, nss1)
  for (i in 1:nss1) {
    ss1[i] <- smry[[i]]$sample_size
    kmean[i] <- smry[[i]]$K_mean
    ksd[i] <- smry[[i]]$K_sd
    dmean[i] <- smry[[i]]$D_mean
    dsd[[i]] <- smry[[i]]$D_sd
    vmean[i] <- smry[[i]]$V_mean
    vsd[i] <- smry[[i]]$V_sd
  }

  cat("N of replications:", smry[[1]]$n_of_replications, "\n")
  cat("Sample Size:", ss1, "\n")

  km <- cbind(kmean, ksd)
  rownames(km) <- ss1
  colnames(km) <- c("Average", "SD")
  cat("\nCongruence Coefficients(K):\n")
  print(t(round(km, 3)))

  dm <- cbind(dmean, dsd)
  rownames(dm) <- ss1
  colnames(dm) <- c("Average", "SD")
  cat("\nDiscrepancies(D):\n")
  print(t(round(dm, 3)))

  vm <- cbind(vmean, vsd)
  rownames(vm) <- ss1
  colnames(vm) <- c("Average", "SD")
  cat("\nVariability of Factor Solutions(V):\n")
  print(t(round(vm,3)))

  invisible(x)
}


#' @export
summary.efaSimListArrayArray <- function(object, lower=.05, upper=.95, ...) {
  nss1 <- length(object)
  smry <- lapply(object, summary.efaSimListArray, lower=lower, upper=upper, plot=FALSE)

  ss1 <- rep(NA, nss1)
  kmean <- rep(NA, nss1)
  ksd <- rep(NA, nss1)
  kq1 <- matrix(NA, nss1, 3)
  dmean <- rep(NA, nss1)
  dsd <- rep(NA, nss1)
  dq1 <- matrix(NA, nss1, 3)
  vmean <- rep(NA, nss1)
  vsd <- rep(NA, nss1)
  vq1 <- matrix(NA, nss1, 3)
  for (i in 1:nss1) {
    ss1[i] <- smry[[i]]$sample_size
    kmean[i] <- smry[[i]]$K_mean
    ksd[i] <- smry[[i]]$K_sd
    kq1[i,] <- smry[[i]]$quantile_of_K
    dmean[i] <- smry[[i]]$D_mean
    dsd[i] <- smry[[i]]$D_sd
    dq1[i,] <- smry[[i]]$quantile_of_D
    vmean[i] <- smry[[i]]$V_mean
    vsd[i] <- smry[[i]]$V_sd
    vq1[i,] <- smry[[i]]$quantile_of_V
  }

  names(kmean) <- ss1
  names(ksd) <- ss1
  rownames(kq1) <- ss1
  colnames(kq1) <- paste0(smry[[1]]$quant_prob*100, "%")

  names(dmean) <- ss1
  names(dsd) <- ss1
  rownames(dq1) <- ss1
  colnames(dq1) <- paste0(smry[[1]]$quant_prob*100, "%")

  names(vmean) <- ss1
  names(vsd) <- ss1
  rownames(vq1) <- ss1
  colnames(vq1) <- paste0(smry[[1]]$quant_prob*100,"%")

  ret <- list(
    n_of_replications=smry[[1]]$n_of_replications,
    sample_size=ss1,
    K_mean=kmean,
    K_sd=ksd,
    K_quantile=kq1,
    D_mean=dmean,
    D_sd=dsd,
    D_quantile=dq1,
    V_mean=vmean,
    V_sd=vsd,
    V_quantile=vq1
  )
  class(ret) <- "summary_efaSimListArrayArray"
  ret
}


#' @export
print.summary_efaSimListArrayArray <- function(x, ...) {
  cat("N of Replications:", x$n_of_replications, "\n")
  cat("Sample Size:", x$sample_size,  "\n")

  cat("\nCongruence Coefficients(K):\n")
  km <- cbind(x$K_mean, x$K_sd, x$K_quantile)
  colnames(km) <- c("Average", "SD", colnames(x$K_quantile))
  print(round(km,3))

  cat("\nDiscrepancies(D):\n")
  km <- cbind(x$D_mean, x$D_sd, x$D_quantile)
  colnames(km) <- c("Average", "SD", colnames(x$K_quantile))
  print(round(km,3))

  cat("\nVariability of Factor Solutions(V):\n")
  vm <- cbind(x$V_mean, x$V_sd, x$V_quantile)
  colnames(vm) <- c("Average", "SD", colnames(x$V_quantile))
  print(round(vm,3))

  invisible(x)
}

#' サンプルサイズによるKの比較のためのグラフ描画
#'
#' サンプルサイズによるKおよびVの比較のためのグラフ描画
#'
#' @param x efaSimListArrayArrayクラスのオブジェクト。run_multiple_efa_sim()関数の出力
#' @param plot "K"または"D"またはV"
#' @param lower シミュレーション結果の分布出力の下限
#' @param upper シミュレーション結果の分布出力の上限
#' @param ... 追加引数
#'
#' @export
plot.efaSimListArrayArray <- function(x, plot="K", lower=.05, upper=.95, ...) {
  smry <- summary(x, lower=lower, upper=upper)
  ss1 <- smry$sample_size
  kq1 <- smry$K_quantile
  dq1 <- smry$D_quantile
  vq1 <- smry$V_quantile

  if (plot=="K") {
    graphics::plot(ss1, kq1[,2], ylim=c(0.5, 1.0), xlab="sample size", ylab="K", type="b", ...)
    graphics::par(new=TRUE);
    graphics::plot(ss1, kq1[,1], lty=2, ylim=c(0.5, 1.0), xlab="", ylab="", type="b", axes=FALSE)
    graphics::par(new=TRUE);
    graphics::plot(ss1, kq1[,3], lty=3, ylim=c(0.5, 1.0), xlab="", ylab="", type="b", axes=FALSE)
    graphics::legend("bottomright", legend=colnames(kq1), lty=c(3,1,2))
  } else if (plot=="D") {
    graphics::plot(ss1, dq1[,2], ylim=c(0, 0.3), xlab="sample size", ylab="D", type="b", ...)
    graphics::par(new=TRUE);
    graphics::plot(ss1, dq1[,1], lty=2, ylim=c(0, 0.3), xlab="", ylab="", type="b", axes=FALSE)
    graphics::par(new=TRUE);
    graphics::plot(ss1, dq1[,3], lty=3, ylim=c(0, 0.3), xlab="", ylab="", type="b", axes=FALSE)
    graphics::legend("topright", legend=colnames(vq1), lty=c(3,1,2))
  } else if (plot=="V") {
    graphics::plot(ss1, vq1[,2], ylim=c(0, 0.3), xlab="sample size", ylab="V", type="b", ...)
    graphics::par(new=TRUE);
    graphics::plot(ss1, vq1[,1], lty=2, ylim=c(0, 0.3), xlab="", ylab="", type="b", axes=FALSE)
    graphics::par(new=TRUE);
    graphics::plot(ss1, vq1[,3], lty=3, ylim=c(0, 0.3), xlab="", ylab="", type="b", axes=FALSE)
    graphics::legend("topright", legend=colnames(vq1), lty=c(3,1,2))
  }

  invisible(x)
}

