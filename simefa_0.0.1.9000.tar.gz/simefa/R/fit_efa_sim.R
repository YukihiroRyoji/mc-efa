#' Coefficient of Congruence (K)の計算
#'
#' Coefficient of Congruence (K)の計算
#' @param pat1 因子負荷量パターン1
#' @param pat2 因子負荷量パターン2
#'
#' @return K Kの値
#' @return forder Kの値が最大になるように並べ変えたpat2の順序
#' @return posinega Kの値が負になった場合に符号を反転させるパターン
#'
#' @export
congruence_coef <- function(pat1, pat2) {
  perm <- function(n) {
    x <- 1:n
    total_perms <- factorial(n)
    res_mat <- matrix(NA, nrow = total_perms, ncol = n)
    current <- sort(x)
    res_mat[1, ] <- current
    if (n == 1) return(res_mat)
    for (k in 2:total_perms) {
      i <- 0
      for (idx in (n - 1):1) {
        if (current[idx] < current[idx + 1]) {
          i <- idx
          break
        }
      }
      j <- n
      while (current[i] >= current[j]) {
        j <- j - 1
      }
      tmp <- current[i]
      current[i] <- current[j]
      current[j] <- tmp
      current[(i + 1):n] <- rev(current[(i + 1):n])
      res_mat[k, ] <- current
    }
    return(res_mat)
  }

  nfac <- ncol(pat1)
  forders <- perm(nfac)
  norder <-nrow(forders)
  K <- rep(NA, norder)
  posinega <- matrix(1, norder, nfac)

  for (i in 1:norder) {
    phi <- rep(NA, nfac)
    for (j in 1:nfac) {
      phi[j] <- (pat1[,j] %*% pat2[,forders[i,j]]) /
        sqrt((pat1[,j] %*% pat1[,j]) * (pat2[,forders[i,j]] %*% pat2[,forders[i,j]]))
      if (phi[j]<0) {
        phi[j] <- (- phi[j])
        posinega[i,j] <- -1
      }
    }
    K[i] <- mean(phi)
  }
  imax <- which.max(K)
  return(list(K=K[imax], forder=forders[imax,], posinega=posinega[imax,]))
}


#' シミュレーションデータにEFAモデルのフィットを行う
#'
#' シミュレーションデータにEFAモデルのフィットを行う
#'
#' @param x シミュレーションデータの行列
#' @param factorloadings 母集団因子負荷行列
#' @param factorcors 母集団因子間相関行列
#' @param rotation 因子回転方法の指定。targetの場合はfactorloadingsをターゲットにターゲット回転を行う。psych::target.rot参照。
#' @param cor 使用する相関行列。"cor"はpearsonの相関係数。"poly"で多分相関係数。psych::fa参照。
#' @param fm 因子抽出方法の指定。psych::fa参照
#'
#' @export
fit_efa_sim <- function (x, factorloadings, factorcors, rotation="geominQ", cor="cor", fm="ml") {
  nvar <- nrow(factorloadings)  # 観測変数の数
  nfac <- ncol(factorloadings)  # 因子数
  ss <- nrow(x)
  #efa_result <- efa(x, nfactors=nfac, rotation=rotation, output="lavaan")
  #loading <- lavInspect(efa_result, "std")$lambda
  #fcor <- lavInspect(efa_result, "std")$psi
  if (rotation=="target") {
    efa_result <- psych::fa(x, nfactors=nfac, rotate="none", cor=cor, fm=fm)
    efa_result <- psych::target.rot(efa_result$loadings, keys=factorloadings)
  } else {
    efa_result <- psych::fa(x, nfactors=nfac, rotate=rotation, cor=cor, fm=fm)
  }
  loading <- unclass(efa_result$loadings)
  fcor <- efa_result$Phi

  K_list <- congruence_coef(factorloadings, loading)
  loading <- loading[,K_list$forder]
  loading <- loading * matrix(K_list$posinega, nvar, nfac, byrow=TRUE)
  fcor <- fcor[K_list$forder,]
  fcor <- fcor[, K_list$forder]
  focr <- fcor * matrix(K_list$posinega, nfac, nfac, byrow=TRUE) * matrix(K_list$posinega, nfac, nfac, byrow=FALSE)

  D <- sqrt(psych::tr(t(loading-factorloadings) %*% (loading-factorloadings)) / (nfac*nvar))

  ret <- list(loadings=loading, population_loadings=factorloadings,
              factor_correlations=fcor, population_factor_correlations=factorcors,
              K=K_list$K, D=D, samplesize=ss)
  class(ret) <- "efaSimList"
  return(ret)
}


#' @export
print.efaSimList <- function(x, ...) {
  cat("Sample Size:", x$samplesize,"\n")
  cat("Coefficient of Congruence(K)):", round(x$K,3),"\n")
  cat("Discrepancy(D):", round(x$D,3), "\n")
  cat("\nFactor Loadings:\n")
  print(round(x$loadings,3))
  cat("\nFacor Correlations:\n")
  print(round(x$factor_correlations, 3))
  cat("\nPopulation Factor Loadings:\n")
  colnames(x$population_loadings) <- paste0("f", 1:ncol(x$population_loadings))
  rownames(x$population_loadings) <- paste0("f", 1:nrow(x$population_loadings))
  print(format(round(x$population_loadings, 3), nsmall=3), quote=FALSE)
  cat("\nPopulation Factor Correlations:\n")
  colnames(x$population_factor_correlations) <- paste0("f",1:ncol(x$population_factor_correlations))
  rownames(x$population_factor_correlations) <- paste0("f",1:nrow(x$population_factor_correlations))
  print(format(round(x$population_factor_correlations, 3), nsmall=3), quote=FALSE)

  invisible(x)
}
