#' 因子モデル
#'
#' 因子負荷量と因子間相関から，共通性，因子寄与，観測変数間の相関係数等を生成する
#'
#' @param fload 因子負荷行列
#' @param fcor 因子間相関行列
#' @export
factor_model <- function(fload, fcor) {
  cormat <- fload %*% fcor %*% t(fload)
  h2 <- diag(cormat)
  u2 <- 1-h2
  diag(cormat) <- 1
  fm <- list(factor_loadings=fload, factor_correlations=fcor, communality=h2, uniqueness=u2, correlation_matrix=cormat)
  class(fm) <- "factor_model"
  fm
}

#' @export
print.factor_model <- function(x, correlation_matrix=FALSE, ...) {
  nfac <- ncol(x$factor_loadings)
  nvar <- nrow(x$factor_loadings)
  fmat <- cbind(x$factor_loadings, x$communality, x$uniqueness)
  colnames(fmat) <- c(paste0("Factor", 1:nfac), "h2", "u2")
  rownames(fmat) <- paste0("y", 1:nvar)
  print(format(round(fmat,3), nsmall=3), quote=FALSE)

  var_explained <- sum(x$communality)
  percent_var_explained <- var_explained / nvar

  cat("\nFactor Correlations:\n")
  mat <- x$factor_correlations
  colnames(mat) <- paste0("Factor", 1:nfac)
  rownames(mat) <- paste0("Factor", 1:nfac)
  print(format(round(mat,3), nsmall=3), quote=FALSE)

  cat("\nSum of h2(Var explained): ", var_explained, "\n", sep="")
  cat("% Var explained: ", round(percent_var_explained*100,2), "%\n", sep="")

  if (correlation_matrix) {
    cat("\nCorrelations:\n")
    mat <- x$correlation_matrix
    colnames(mat) <- paste0("y", 1:nvar)
    rownames(mat) <- paste0("y", 1:nvar)
    print(format(round(mat, 3), nsmall=3), quote=FALSE)
  }

  invisible(x)
}

